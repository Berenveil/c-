﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectAdo
{
    internal class Cargo
    {
        private int id { get; set; }
        public string articleModel { get; set; }
        public string nameModel { get; set; }
        public int weightModel { get; set; }
        public int volumeModel { get; set; }
        public CategoryEnums categoryModel { get; private set; }
        public DateTime DateModel { get; set; }

        public Cargo(int id, string articleModel, string nameModel, int weightModel, int volumeModel, CategoryEnums categoryModel, DateTime DateModel)
        {
            if (string.IsNullOrEmpty(articleModel)) throw new Exception("Артикул отсутствует. Ошибка");
            if (string.IsNullOrEmpty(nameModel)) throw new Exception("Имя модели отсутствует. Ошибка");

            this.id = id;
            this.articleModel = articleModel;
            this.nameModel = nameModel;
            this.weightModel = weightModel;
            this.volumeModel = volumeModel;
            this.categoryModel = categoryModel;
            this.DateModel = DateModel;
        }
    }
}
