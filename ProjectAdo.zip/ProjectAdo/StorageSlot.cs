﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectAdo
{
    internal class StorageSlot
    {
        public int ZoneNumber {  get; set; }
        public int Rack { get; set; }
        public int Shelf { get; set; }
        public int MaxCarrying { get; set; }
        public EmploymentStatusEnum EmploymentStatus { get; private set; }

        public StorageSlot(int ZoneNumber, int Rack, int Shelf, int MaxCarrying, EmploymentStatusEnum EmploymentStatus)
        {
        }
    }
}
