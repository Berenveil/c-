﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectAdo
{
    public enum CategoryEnums
    {
        Perishable,
        Dangerous,
        Fragile,
        Standard
    }
}
